<?php
for ($par=0; $par<100; $par=$par+2){
	
	echo "<p>Vamos por $par</p>";

}
?>