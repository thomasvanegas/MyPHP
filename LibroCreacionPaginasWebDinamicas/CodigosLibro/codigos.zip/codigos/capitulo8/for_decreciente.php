<?php
for ( $faltan=10; $faltan>0; $faltan=$faltan-1){

	echo "<p>Están faltando $faltan</p>";
	
}
?>