<?php
$animales[4] = "Perro";
$animales[5] = "Gato";
$animales[21] = "Tortuga";
$animales[3] = "Hamster";
$animales[45] = "Canario";

foreach ($animales as $valor){

	print("<p>El animal actual es ".$valor."</p>");

}
?>