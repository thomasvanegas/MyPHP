<?php
if ($abierto = fopen ("archivo.txt", "r")){

// Aquí haríamos alguna operación...

} else {

	echo 'No pudo abrirse el archivo';

}
?>