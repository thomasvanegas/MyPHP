<?php
$limite = 5;

do {

	echo $limite;

} while ($limite>9);
?>