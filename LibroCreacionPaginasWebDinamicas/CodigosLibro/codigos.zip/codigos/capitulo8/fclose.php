<?php
$abierto = fopen ("archivo.txt", "r");
// Aquí leeríamos, o escribiríamos, o añadiríamos algo...
// y finalmente, lo cerraríamos:
fclose ($abierto);
?>