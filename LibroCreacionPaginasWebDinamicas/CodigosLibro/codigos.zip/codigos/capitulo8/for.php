<?php
for ( $dia=1; $dia<32; $dia=$dia+1){

	echo "<p>Hoy es el día $dia</p>";

}
?>