<?php
$concatenado = 'Texto concatenado con una constante '.HEADING_TITLE.' que ahora sí se reemplazará por su valor';
?>