<?php
$numeros[0] = 75;
$numeros[1] = 90;
$numeros[2] = 45;
print ($numeros[0]."<br>".$numeros[1]."<br>".$numeros[2]);
// escribirá: 75<br>90<br>45
?>