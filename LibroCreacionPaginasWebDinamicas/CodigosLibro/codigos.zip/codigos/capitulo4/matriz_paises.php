<?php
$paises[0] = "Afganistán";
$paises[1] = "Albania";
$paises[2] = "Alemania";
$paises[3] = "Andorra";
$paises[4] = "Angola";

print ($paises[0]."<br>".$paises[1]."<br>".$paises[2]."<br>".$paises[3]."<br>".$paises[4]);
// escribirá: Afganistán<br>Albania<br>Alemania<br>Andorra<br>Angola
?>