<?php
$paises = array("Argentina", "Uruguay", "Chile", "Perú");
// crea una matriz llamada $paises de cuatro elementos con índices numerados a partir de cero.
$loteria = array(23,8,36,12,99);
// crea una matriz de cinco elementos con índices numerados a partir de cero.
$usuario = array("Juan Pérez", 24, "casado", 800);
// crea una matriz de cuatro elementos con índices numerados a partir de cero.
?>