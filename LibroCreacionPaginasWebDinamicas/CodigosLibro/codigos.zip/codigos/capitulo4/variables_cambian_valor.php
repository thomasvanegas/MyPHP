<?php
$precio = 100;
$cantidad = 5;
$total = $precio * $cantidad;
/* $total contiene 500 */
$aumento = 2;
$total = $total + $aumento;
/* $total ahora contiene 502 */
?>