<?php
define("PI", 3.1415926);
define("BR", "<br />");
define("LIBRO", "PHP, de Hernán Beati");
print(PI);
print(BR);
print(LIBRO);
?>