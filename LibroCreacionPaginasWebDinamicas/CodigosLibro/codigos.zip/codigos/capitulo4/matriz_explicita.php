<?php
$paises[0] = "Afganistán";
$paises[1] = "Albania"; // etc.

print ($paises[0]);
print ($paises[1]); // etc.
?>