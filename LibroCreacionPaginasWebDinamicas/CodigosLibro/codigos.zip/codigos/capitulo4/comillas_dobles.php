<?php
$nombre = "Pepe";
$mensaje = "Hola, señor $nombre";
print($mensaje);
?>