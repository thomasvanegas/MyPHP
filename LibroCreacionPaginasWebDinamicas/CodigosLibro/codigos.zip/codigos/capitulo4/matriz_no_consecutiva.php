<?php
$productos[1234] = "Televisor LG de 42 pulgadas";
$productos[145] = "Televisor Sony de 29 pulgadas";
$productos[899] = "Televisor portátil de 12 voltios";
?>