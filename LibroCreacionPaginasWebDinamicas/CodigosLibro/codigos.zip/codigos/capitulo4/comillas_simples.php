<?php
$sitio = 'PHP 6';
$concatenacion = '<h1 class="resaltado">Bienvenidos a $sitio</h1>';
?>