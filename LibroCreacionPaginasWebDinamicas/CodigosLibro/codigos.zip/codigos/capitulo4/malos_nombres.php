<?php
$dato_123 = "Pepe";
$dato_46 = "Hola, señor $dato_123";
print($dato_46);
?>