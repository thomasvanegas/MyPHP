<?php
$cantidad = 5;
$precio = 3;
$importe = $cantidad * $precio;
print($importe);
?>