<?php
$paises = array(1 => "Argentina", "Uruguay", "Chile", "Perú");
// crea una matriz llamada $paises de cuatro elementos, cuyo primer elemento posee un "1" como índice, el segundo un 2 y así sucesivamente.
?>
<?php
$paises = array("Argentina", 10 => "Uruguay", "Chile", "Perú");
// crea una matriz llamada $paises de cuatro elementos, cuyo primer elemento posee un "0" como índice, el segundo un "10" y luego el resto continúa con "11" y "12".
?>