<?php
$lugar1 = "Buenos Aires"; /* Correcto, puede comenzar por una letra */
$_lugar_2 = "México"; /* Correcto, puede comenzar por un guión bajo */
$3_lugar = "España"; /* Incorrecto, no puede comenzar por un número */
?>