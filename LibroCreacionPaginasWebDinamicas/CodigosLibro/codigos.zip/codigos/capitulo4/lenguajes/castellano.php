<?php
define('NAVBAR_TITLE', 'Mi Cuenta');
define('HEADING_TITLE', 'Datos de Mi Cuenta');
define('OVERVIEW_TITLE', 'Resumen');
define('OVERVIEW_SHOW_ALL_ORDERS', '(ver todos mis pedidos)');
define('OVERVIEW_PREVIOUS_ORDERS', 'Pedidos Anteriores');
?>