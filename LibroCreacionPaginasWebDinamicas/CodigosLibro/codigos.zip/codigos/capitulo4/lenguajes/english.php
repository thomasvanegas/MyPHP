<?php
define('NAVBAR_TITLE', 'My Account');
define('HEADING_TITLE', 'My Account Information');
define('OVERVIEW_TITLE', 'Overview');
define('OVERVIEW_SHOW_ALL_ORDERS', '(show all orders)');
define('OVERVIEW_PREVIOUS_ORDERS', 'Previous Orders');
?>