<?php
$comillasDobles = "Texto entre comillas dobles, puede contener 'comillas simples' dentro sin problemas";
$comillasSimples = 'Texto entre comillas simples, puede contener "comillas dobles" pero sin variables dentro, porque usamos comillas simples para delimitar el inicio y fin del bloque';
$escapeDoble = "Texto con \"comillas\" dobles escapadas";
$escapeSimple = 'Texto con \'comillas\' simples escapadas';
$variablesDobles = "Texto con variables como $nombre y $apellido intercaladas entre comillas dobles, que se reemplazarán por su valor";
$variablesSimples = 'Texto con variables como $nombre y $apellido intercaladas entre comillas simples, que no se reemplazarán por su valor, quedará escrito $nombre y $apellido tal cual';
?>