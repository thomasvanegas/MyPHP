<?php
$nombre = 'Juan';
$apellido = 'Pérez';
$concatenacion = '<p>Su nombre y apellido es '.$nombre.$apellido.'</p>';
?>