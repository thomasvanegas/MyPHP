<?php
$datos["nombre"] = "Juan Pérez";
$datos["edad"] = 24;
$datos["estado"] = "casado";
$datos["sueldo"] = 800;
print ($datos["nombre"]); // escribe: Juan Pérez
?>