<!DOCTYPE html">
<html lang="es">
<head>
<meta charset="utf-8">
<title>Constantes</title>
</head>
<body>
<h1><?php print("Bienvenido a HEADING_TITLE"); ?></h1>
<!-- No se reemplazará por su valor, se escribirá el texto HEADING_TITLE tal cual, letra por letra -->
<h2><?php print('Hola OVERVIEW_TITLE'); ?></h2>
<!-- Tampoco se reemplazará por su valor, se escribirá el texto OVERVIEW_TITLE tal cual, letra por letra -->
<?php
$comillasDobles = "Texto entre comillas dobles, no puede contener constantes como HEADING_TITLE porque no se reemplazarán por su valor";
$comillasSimples = 'Texto entre comillas simples, tampoco puede contener constantes como HEADING_TITLE porque no se reemplazarán por su valor';
?>
<!-- No se reemplazarán las constantes por su valor. -->
</body>
</html>