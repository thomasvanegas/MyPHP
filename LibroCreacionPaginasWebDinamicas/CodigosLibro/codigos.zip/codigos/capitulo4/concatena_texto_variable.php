<?php
$nombre = 'Pepe';
$concatenacion = '<p id="saludo">Hola '.$nombre.'</p>';
?>