<?php
$numero = 514;
print ($numero);
// escribe 514.
?>