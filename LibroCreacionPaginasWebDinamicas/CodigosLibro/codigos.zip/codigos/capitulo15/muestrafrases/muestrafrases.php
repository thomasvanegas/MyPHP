<?php
add_action('widgets_init', 'cargar_frases');

function cargar_frases(){
	register_widget('muestrafrases');
}

class muestrafrases extends WP_Widget {

	// Método constructor:
	function muestrafrases() {

		// Opciones del Widget
		$widget_ops = array('description' => __('Un widget que muestra frases.', 'muestrafrases'));

		// Controles del Widget
		$control_ops = array('width' => 200, 'height' => 350, 'id_base' => 'muestrafrases');

		// Creación del Widget
		$this->WP_Widget('muestrafrases', __('Muestra Frases', 'muestrafrases'), $widget_ops, $control_ops);
	}// fin de muestrafrases

	function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		$instance['title'] = strip_tags( $new_instance['title'] );
 		$instance['lang'] = strip_tags( $new_instance['lang'] );
		$instance['alignment'] = $new_instance['alignment'];
		
		return $instance;
	}// fin de update

	function form($instance) {

		// Configuración de valores por defecto para el widget
		$defaults = array( 'title' => __('Ejemplo', 'example'),  'lang' => 'es', 'alignment' => false );
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>
		
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Titulo:', 'hybrid'); ?></label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" size="30" />
		</p>

			<p>
			<label for="<?php echo $this->get_field_id( 'lang' ); ?>"><?php _e('Idioma:', 'lang'); ?></label>
			<input id="<?php echo $this->get_field_id( 'lang' ); ?>" name="<?php echo $this->get_field_name( 'lang' ); ?>" value="<?php echo $instance['lang']; ?>" size="2" />
		</p>

		<p>
			<input class="checkbox" type="checkbox" <?php if($instance['alignment'] == true) echo 'checked'; ?> id="<?php echo $this->get_field_id( 'alignment' ); ?>" name="<?php echo $this->get_field_name( 'alignment' ); ?>" /> 
			<label for="<?php echo $this->get_field_id( 'alignment'); ?>"><?php _e('Alineación centrada?', 'alignment'); ?></label>
		</p>
	
		
	<?php
	}// fin de form

	/**
	 * Cómo mostrar el widget en la pantalla.
	 */
	function widget( $args, $instance ) {
		extract( $args );

		// Nuestras variables de configuración del widget
		$title = apply_filters('widget_title', $instance['title'] );
		$lang = $instance['lang'];
		$alignment = $instance['alignment'];

		// Parte previa al widget (definida en las plantillas o themes)
		echo $before_widget;

		// Muestra el título del widget si fue definido
		if ( $title )
			echo $before_title . $title . $after_title;

		// Muestra el nombre del widget, si fue definido
		$this->buildWidget($lang, $alignment);
			
		// Parte siguiente al widget (definida en los themes)
		echo $after_widget;
	}
		
	
	function buildWidget($lang, $alignment) {
				
		if($alignment == true) {
			$alignmentclass = 'centered';
		}
		
		echo '<div class="muestrafrases">
		<dl class="'.$alignmentclass.'">
		';	
		
			$archivo = ABSPATH . "/wp-content/plugins/muestrafrases/frases.txt";// La ruta al archivo

	$frases = file($archivo);
	// A $frases lo convertimos en una matriz con tantas celdas como líneas -renglones- tenía el archivo de texto.

	shuffle($frases); // Mezclamos el contenido de esa matriz con la función shuffle, por lo cual, no sabemos cuál frase quedó en el primer lugar, y la mostramos: 

	echo ("<p>".$frases[0]."</p>");


		
		echo '
		</dl>
		</div>
		<div style="clear: both;"></div>
		';
	}
	
	function replaceChars($data){
		$search = array('Ä', 'Ö', 'Ü', 'ä', 'ö', 'ü', ' ');
		$replace = array('Ae', 'Oe', 'Ue', 'ae', 'oe', 'ue', '%20');
		$output = str_replace($search, $replace, $data);
		
		return $output;
	}
}

// Esta es la función que llamará a mostrar, que a su vez es quien crea una instancia de “muestrafrases” y ejecuta su método buildWidget que realmente escribe el código del widget.
add_shortcode('muestrafrases', 'mostrar');

function mostrar($atts, $content = null) {

	$muestrafrases = new muestrafrases();
	ob_start();
	$muestrafrases->buildWidget($language, $alignment);
	$output = ob_get_contents();
	ob_end_clean();
	return $output;
}
?>