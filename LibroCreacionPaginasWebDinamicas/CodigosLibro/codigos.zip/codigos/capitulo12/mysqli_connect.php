<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Conexión</title>
</head>
<body>
<?php
if ( mysqli_connect("localhost","root","clave","base") ){

	echo "<p>MySQL le ha dado permiso a PHP para ejecutar consultas con ese usuario y clave</p>";
	
} else {

	echo "<p>MySQL no conoce ese usuario y password, y rechaza el intento de conexión</p>";
	
}
?>
</body>
</html>