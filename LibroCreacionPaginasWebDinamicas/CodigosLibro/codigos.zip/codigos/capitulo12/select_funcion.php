<?php
function generaMenuSeleccion($datos,$name,$label){

	$codigo = '<label>'.$label.'</label>'."\n";
	$codigo = $codigo.'<select name="'.$name.'">'."\n";

	while($fila = mysql_fetch_array($datos)){
	
		$codigo = $codigo.'<option value="'.$fila["id"].'">'.utf8_encode($fila["pais"]).'</option>'."\n";

	}

	$codigo = $codigo."</select>\n";
	return $codigo;

}
?>

<?php
// ATENCION: primero necesitaremos cargar las siguientes variables pasadas como parámetros: $paquete, $name y $label
$codigoMenu = generaMenuSeleccion($paquete,$name,$label);
echo $codigoMenu;
?>