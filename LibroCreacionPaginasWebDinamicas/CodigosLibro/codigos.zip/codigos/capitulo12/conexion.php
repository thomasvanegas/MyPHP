<?php
$host = "localhost";
$usuario = "root";
$clave = "";
$base = "cursos";
?>