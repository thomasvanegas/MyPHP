<?php
function tabular($datos){

	// Abrimos la etiqueta table una sola vez:
	$codigo = '<table border="1" cellpadding="3">';

	// Vamos acumulando de a una fila "tr" por vuelta:
	while ( $fila = @mysqli_fetch_array($datos) ){
		
		$codigo .= '<tr>';
		
		// Vamos acumulando tantos "td" como sea necesario:
		$codigo .= '<td>'.utf8_encode($fila["id"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["nombre"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["apellido"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["edad"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["pais"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["especialid	ad"]).'</td>';
	
		// Cerramos un "tr":
		$codigo .= '</tr>';

	}

	// Finalizado el bucle, cerramos por única vez la tabla:
	$codigo .= '</table>';
	
	return $codigo;
	
}
?>