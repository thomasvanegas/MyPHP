<?php
function conectarBase($host,$usuario,$clave,$base){

	if (!$enlace = @mysqli_connect($host,$usuario,$clave,$base)){

		return false;
	
	} else {
	
		return true;
	
	}

}

function consultar($consulta){

	if (!$datos = mysqli_query($enlace,$consulta) or mysqli_num_rows($consulta)<1){

		return false; // si fue rechazada la consulta por errores de sintaxis, o ningún registro coincide con lo buscado, devolvemos false

	} else {

		return $datos; // si se obtuvieron datos, los devolvemos al punto en que fue llamada la función
		
	}
}
?>