<?php
// Incluimos los datos de conexión y las funciones:
include("conexion.php");
include("funciones.php");

// Usamos esas variables:
if ( conectarBase($host,$usuario,$clave,$base) ){

	// Aquí haríamos el resto de operaciones...
	} else {

		echo "<p>Servicio interrumpido</p>";
	}
?>