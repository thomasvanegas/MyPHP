<?php
function crearCasillas($datos,$leyenda){

	// Abrimos el fieldset con su leyenda:
	$codigo = '<fieldset><legend>'.$leyenda.'</legend>'."\n";

	// Vamos mostrando un label y un input por vuelta:
	while ( $fila = @mysqli_fetch_array($datos) ){

		// Un label:
		$codigo .= '<label>'.utf8_encode($fila["nombre"]);
	
		// Un input:
		$codigo = $codigo.'<input type="checkbox" name="dato'.$fila["id"].'" id="dato'.$fila["id"].'">'."\n";
	
		// Cerramos el label:
		$codigo .= '</label><br>'."\n";

	}

	$codigo .= '</fieldset>'."\n";
	return $codigo;

}
?>

<?php
// ATENCION: primero necesitaremos conectarnos a la base, seleccionarla, etc. y cargar el paquete de datos que pasaremos como parámetros en $paquete:
$casillas = crearCasillas($paquete,'Tu voto puede sumarse a
más de un empleado','empleado');
echo $casillas;
?>