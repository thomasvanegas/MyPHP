<?php
function crearRadios($datos,$leyenda,$name){

	// Abrimos el fieldset con su leyenda:
	$codigo = '<fieldset><legend>'.$leyenda.'</legend>'."\n";

	// Vamos mostrando un label y un input por vuelta:
	while ( $fila = @mysqli_fetch_array($datos) ){

		// Un label:
		$codigo .= '<label>'.utf8_encode($fila["nombre"]);
	
		// Un input:
		$codigo = $codigo.'<input type="radio" name="'.$name.'" id="dato'.$fila["id"].'">'."\n";
	
		// Cerramos el label:
		$codigo .= '</label><br>'."\n";

	}

	$codigo .= '</fieldset>'."\n";
	return $codigo;

}
?>

<?php
// ATENCION: primero necesitaremos conectarnos a la base, seleccionarla, etc. y cargar el paquete de datos que pasaremos como parámetros en $paquete:
$radios = crearRadios($paquete,'Votemos el empleado del mes','empleado');
echo $radios;
?>