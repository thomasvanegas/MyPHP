<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Conexión</title>
</head>
<body>
<?php
// 1) Conexión y selección de base
if ($conexion = mysqli_connect("localhost","root","","cursos")){

	echo "<p>MySQL le ha dado permiso a PHP para ejecutar consultas con ese usuario y password</p>";

	// 2) Preparar la orden SQL
	$consulta = "SELECT * FROM mensajes";
	
	// 3) Ejecutar la orden y obtener datos
	
	$datos = mysqli_query($conexion,$consulta);

	// 4) Ir imprimiendo las filas resultantes
	while ( $fila = mysqli_fetch_array($datos) ){
	 
	 	echo "<p>";
		echo $fila["id"];
		echo " - "; // un separador
		echo $fila["nombre"];
		echo " - "; // un separador
		echo $fila["email"];
		echo " - "; // un separador
		echo $fila["mensaje"];
		echo "</p>";
	
	}

} else {

	echo "<p>MySQL no conoce ese usuario y password</p>";

}
?>
</body>
</html>