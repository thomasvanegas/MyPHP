<?php
// Incluimos los datos de conexión y las funciones:
include("conexion.php");
include("funciones.php");

// Usamos esas variables:
if ( conectarBase($host,$usuario,$clave,$base) ){
	
	$consulta = "SELECT * FROM empleados";
	
	if ( $paquete = consultar($consulta) ){
	
		// Aquí llamaremos a una función que muestre esos datos

	} else {
	
		echo "<p>No se encontraron datos</p>";

	}
	
} else {

	echo "<p>Servicio interrumpido</p>";

}
?>