<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Saludar</title>
</head>
<body>
<p>
<?php
if ($_POST["sexo"] == "masculino"){

   print ("¡Hola hombre!");

} else {

   print ("¡Hola mujer!");

}
?>
</p>
</body>
</html>
