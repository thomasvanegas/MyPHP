<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Datos</title>
</head>
<body>
<?php
print ("<p>Los valores fueron: ");
print ("<br>");
print ($_GET["nombre"]);
print ("<br>");
print ($_GET["apellido"]);
print ("<br>");
print ($_GET["edad"]);
print ("</p>");
?>
</body>
</html>
