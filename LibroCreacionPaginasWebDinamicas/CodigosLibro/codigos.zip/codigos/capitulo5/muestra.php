<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Formulario</title>
</head>
<body>
<p>
  <?php
print ("Su direccion es: ");
print ($_POST["direccion"]);
?>
</p>
</body>
</html>
