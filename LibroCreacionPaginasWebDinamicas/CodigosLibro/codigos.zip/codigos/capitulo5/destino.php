<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Saludar</title>
</head>
<body>
<p><?php print($_GET["nombre"]); ?></p>
</body>
</html>
