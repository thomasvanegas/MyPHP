<?php
include ("alCuadrado.class.php");

$resultado = new alCuadrado();

$resultado->cifra = 45;
/* Aquí le definimos una propiedad como si fuera una variable interna, de alcance local. */

print ("Resultado: ".$resultado->calcularCuadrado());
?>