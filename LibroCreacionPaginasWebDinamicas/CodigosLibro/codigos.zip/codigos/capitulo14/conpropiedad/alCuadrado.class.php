<?php
class alCuadrado {

	public $cifra;

	function calcularCuadrado(){

		return ($this->cifra * $this->cifra);
	
	}

}
?>