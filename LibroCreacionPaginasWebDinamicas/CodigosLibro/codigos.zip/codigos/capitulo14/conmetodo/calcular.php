<?php
include ("alCuadrado.class.php");

$instancia = new alCuadrado();

print ("Resultado: ".$instancia->calcularCuadrado(100));
/* Número a elevar (podría llegar desde un formulario o enlace que envíe variables a esta página). */
?>