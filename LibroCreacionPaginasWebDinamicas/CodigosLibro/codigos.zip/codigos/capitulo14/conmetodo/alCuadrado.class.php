<?php
class alCuadrado {

	private $numero;

	function calcularCuadrado($cifra){

		$this->resultado = $cifra * $cifra;
		return ($this->resultado);

	}

}
?>