<?php
class alCuadrado {

	private $cifra;

	function getCifra(){
		
		return ($this->cifra);
	
	}
}
?>