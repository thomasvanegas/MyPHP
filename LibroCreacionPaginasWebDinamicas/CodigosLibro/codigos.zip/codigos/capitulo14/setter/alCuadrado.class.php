<?php
class alCuadrado {

	private $cifra;

	function setCifra($valor){

		$this->cifra = $valor;

	}
	}
?>