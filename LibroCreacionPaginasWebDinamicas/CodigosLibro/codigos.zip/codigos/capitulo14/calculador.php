<?php
include ("alCuadrado.class.php");

$instancia = new alCuadrado();

print ("Elevar el 4 al cuadrado da como resultado: ".$instancia->calcularCuadrado());
?>