<html>
<?php
require "nxgooglemapsapi.php";


$api = new NXGoogleMapsAPI();

// setup the visual design of the control
$api->setWidth(800);
$api->setHeight(600);
$api->setZoomFactor(5);
$api->addControl(GSmallMapControl);

// add a point. 
$api->addGeoPoint(19.4270499,-99.1275711, "Mexico DF", false);
// center to a point
$api->setCenter(19,-90);


?>
<head>

<?php echo $api->getHeadCode(); ?>

</head>

<body onLoad="<?php echo $api->getOnLoadCode(); ?>">

<h1> Adding Geopoints to the map </h1>

<?php echo $api->getBodyCode(); ?>

</body>
</html>