**************************************
  BEFORE STARTING THE EXAMPLES
**************************************

For checking out the examples, you must register your google maps api key 
to localhost and paste it into the nxgooglemapsapi.php-file

E.g. you need to edit the constant: 

  define(GoogleMapsKey, '<your api key>'); 