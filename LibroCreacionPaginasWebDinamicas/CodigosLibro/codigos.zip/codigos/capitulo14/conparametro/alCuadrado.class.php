<?php
class alCuadrado {

	private $numero;

	function __construct($cifra){

		$this->numero = $cifra;
	
	}
	
	function calcularCuadrado(){
	
		return ($this->numero * $this->numero);
	
	}

}
?>