<?php
include ("alCuadrado.class.php");

$cantidad = 10;
/* Número a elevar (también podría llegar desde un formulario o enlace que envíe variables a esta página). */

$instancia = new alCuadrado($cantidad);
/* Aquí le pasamos el número en el momento en que se
ejecuta el método constructor.*/

print ("Elevar ".$cantidad." al cuadrado da: ");
echo $instancia->calcularCuadrado();
?>