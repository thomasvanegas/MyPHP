<?php
include("formulario.class.php");

$miFormulario = new Formulario();

?>