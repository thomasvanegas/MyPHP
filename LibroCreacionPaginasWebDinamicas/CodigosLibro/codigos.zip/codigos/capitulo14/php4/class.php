<?php
class unaClaseAntigua {

	var $nombre;
	
	function unaClaseAntigua(){
		// etc...
	}

}
?>