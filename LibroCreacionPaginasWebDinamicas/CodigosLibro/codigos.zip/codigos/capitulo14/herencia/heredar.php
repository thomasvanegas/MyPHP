<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Herencia</title>
</head>

<body>
<?php
include("alCuadrado.class.php");

$cubo = new alCubo();
$cubo->numero = 3;
// Podría recibirse desde una variable

print ("<p>Resultado de ".$cubo->numero." al cuadrado: ".$cubo->elevaAlCuadrado()."</p>");

print ("<p>Resultado de ".$cubo->numero." al cubo: ".$cubo->elevaAlCubo()."</p>");
?>
</body>
</html>