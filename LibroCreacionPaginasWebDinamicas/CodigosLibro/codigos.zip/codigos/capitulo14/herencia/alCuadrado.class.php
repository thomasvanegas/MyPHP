<?php
class alCuadrado {

	public $numero;

	function elevaAlCuadrado(){
	
		return ($this->numero * $this->numero);
	
	}
}

class alCubo extends alCuadrado{

	function elevaAlCubo(){

		return ($this->elevaAlCuadrado() * $this->numero);
	
	}
}
?>