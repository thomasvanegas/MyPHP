<?php
class alCuadrado {

	private $numero;

	function alCuadrado(){

		$this->numero = 4;

	}

	function calcularCuadrado(){

		return $this->numero * $this->numero;
		}

}
?>