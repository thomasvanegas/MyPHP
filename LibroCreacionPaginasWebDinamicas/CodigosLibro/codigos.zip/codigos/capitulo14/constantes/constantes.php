<?php
include("base.class.php");
$base = new Base();

echo $base->getUsuario();

echo "<br />";

echo $base->getClave();
?>