<?php
class Base {

	const usuario="root";
	const clave="clave";
	
	function getUsuario(){

		return self::usuario;

	}
	
	function getClave(){

		return self::clave;

	}
}
?>