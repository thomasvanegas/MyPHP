<?php
/*class Prueba {

	public static $empresa="ACME";

}

echo Prueba::empresa;
*/?>

<?php
class miClase {

	public static function estatizar();

}

miClase::estatizar;
?>