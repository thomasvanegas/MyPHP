<?php
function verificarLongitud($cadena,$maximo){

	$cuantas_letras = strlen($cadena);

	if ($cuantas_letras < $maximo){
	
		return true;
	
	} else {
		
		return false;
	
	}
}

// lo usamos, suponiendo que llega vía "post" un "comentario":
if (verificarLongitud($_POST["comentario"],200)){

	echo "Correcto";

} else {

	echo "La longitud ingresada supera el máximo de 200 caracteres...";

}
?>