<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Recomendación</title>
</head>
<body>
<form action="envios.php" method="post">
    <fieldset>
    <legend>Recomendar esta página:</legend>

        <label>Su nombre:
            <input type="text" name="nombreSuyo">
        </label>
    
        <label>Su Email:
            <input type="text" name="emailSuyo">
        </label>
        
        <label>Nombre del destinatario:
            <input type="text" name="nombreAmigo">
        </label>
        
        <label>Email del destinatario:
            <input type="text" name="emailAmigo">
        </label>
        
        <label>Enviar datos:
            <input type="submit" value="Enviar">
        </label>
    </fieldset>
</form>
</body>
</html>