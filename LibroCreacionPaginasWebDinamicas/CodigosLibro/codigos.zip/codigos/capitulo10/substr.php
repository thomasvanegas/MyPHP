<?php
$texto = "Este es un curso de PHP";
$inicio = 5;
// Los caracteres se numeran desde cero

$parte = substr($texto, $inicio);

echo $parte;
// Mostrará: “es un curso de PHP”, es decir, desde el caracter 5 hasta el final del string.
?>