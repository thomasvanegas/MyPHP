<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Envíos</title>
</head>
<body>
<?php
$asunto = $_POST["nombreAmigo"].": ".$_POST["nombreSuyo"]." te recomienda visitar www.sitio.com.ar";

$mensaje = $_POST["nombreSuyo"]." ha visitado www.sitio.com.ar y te recomienda que visites este sitio";

$remite = "From: Hernán Beati <hernan@beati.com.ar>";

if (mail ($_POST["emailAmigo"], $asunto, $mensaje, $remite)){
// Notemos cómo agregamos esta cabecera en cuarto lugar dentro de los paréntesis

	print ("<p>Gracias por su recomendación</p>");

} else {

	print ("<p>Ha fallado el servidor de correos, intente más tarde</p>");

}
?>
</body>
</html>