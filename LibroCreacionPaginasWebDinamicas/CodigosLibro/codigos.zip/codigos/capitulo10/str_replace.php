<?php
$cadena = "Este es mi comentario alegre :-) Saludos!";

$buscar = ":-)";
$reemplazo = '<img src="sonrisa.gif" alt="sonrisa">';

$nuevacadena = str_replace ($buscar, $reemplazo, $cadena);

print ($nuevacadena); // Mostrará la imagen del emoticono dentro del texto
?>