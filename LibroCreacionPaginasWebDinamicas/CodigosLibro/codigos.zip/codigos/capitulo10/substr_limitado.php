<?php
$texto = "Esta es una parte del string";
$inicio = 12;
$cuantos = 5;

$parte = substr($texto, $inicio, $cuantos);

echo $parte;
// Mostrará: "parte".
?>