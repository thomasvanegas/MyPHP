<?php
$formateado = nl2br($_POST["comentario"]);
echo $formateado;
?>