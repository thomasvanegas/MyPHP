<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Envíos</title>
</head>
<body>
<?php
$asunto = $_POST["nombreAmigo"].": ".$_POST["nombreSuyo"]." te recomienda visitar www.sitio.com.ar";

$mensaje = $_POST["nombreSuyo"]." ha visitado www.sitio.com.ar y te recomienda que visites este sitio";

if (mail ($_POST["emailAmigo"], $asunto, $mensaje)){

	print ("<p>Gracias por su recomendación</p>");

} else {

	print ("<p>Ha fallado el servidor de correos, intente más tarde</p>");

}

// Una vez realizado el envío anterior, proseguimos:
$miAsunto = "Nueva recomendación";

$miMensaje = $_POST["nombreAmigo"]." le recomendó a ".$_POST["nombreSuyo"]." y sus casillas son: ".$_POST["emailAmigo"]." y ".$_POST["emailSuyo"];

if (mail ("nosotros@nuestrositio.com"], $miAsunto, $miMensaje)){

	print ("<p>Hemos recibido sus datos</p>");

} else {

	print ("<p>Ha fallado el servidor de correos, no poseemos copia de sus datos</p>");

}
?>
</body>
</html>