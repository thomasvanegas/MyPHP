<?php
$direccion = "www.pagina.com.ar";

$sitio = substr($direccion,4,-7);

print($sitio);
// Imprimirá "pagina"
?>