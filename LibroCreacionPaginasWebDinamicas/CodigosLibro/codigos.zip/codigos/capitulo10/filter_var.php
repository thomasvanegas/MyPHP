<?php
$casilla="pepe@deja espacio.com";

if ( filter_var($casilla,FILTER_VALIDATE_EMAIL) ){

	echo "<p>Casilla correcta</p>";

} else {

	echo "<p>No es correcta la casilla</p>";

}
?>