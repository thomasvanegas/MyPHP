<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Consulta</title>
</head>
<body>
<?php
$destino = "micasilla@misitio.com";

mail ($destino, $_POST["asunto"], $_POST["mensaje"]);

print ("<p>Muchas gracias por su mensaje</p>");
?>
</body>
</html>