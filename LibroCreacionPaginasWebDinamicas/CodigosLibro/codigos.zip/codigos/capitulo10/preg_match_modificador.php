<?php
/* Suponemos que el usuario escribió un Comentario en la página
anterior, y se almacenó en la variable $comentario */

$prohibido = "tonto";

if ( preg_match("/$prohibido/i", $comentario) ){

	print ("No se permite esa palabra. Escriba su comentario con mayor cortesía");
	
} else {

	print ("Gracias por su comentario");

}
?>