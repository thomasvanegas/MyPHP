<?php
/* Suponemos que el usuario completó sus datos en la página
anterior, y se almacenaron en las variables $nombre, $email y
$comentario */
$nombre ="pepe";
$email = "pepe@pepe.com";
$comentario = "Hola";

$datos = array($nombre, $email, $comentario);

$unido = implode(":", $datos); // Se le pasa la matriz entera y la convierte en una cadena de caracteres que queda almacenada en la variable $unido

print ($unido);
?>