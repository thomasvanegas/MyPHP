<?php
$navidad = mktime(23,59,59,12,24,2020); // No lleva comillas

print("La navidad de 2020 sucederá en el instante: ".$navidad);
?>