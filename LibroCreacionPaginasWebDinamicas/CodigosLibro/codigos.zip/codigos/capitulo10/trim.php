<?php
$cadena = "\tabcd \n";
$limpio = trim($cadena);
print ($limpio);
// Escribe “abcd”, sin tabulador ni espacios ni salto de línea.
?>