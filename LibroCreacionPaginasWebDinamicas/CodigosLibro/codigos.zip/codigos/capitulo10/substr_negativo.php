<?php
$cadena = "www.sitio.com.ar";

$sitio = substr($cadena,-7,7);

print($sitio);
// Mostrará ".com.ar"
?>