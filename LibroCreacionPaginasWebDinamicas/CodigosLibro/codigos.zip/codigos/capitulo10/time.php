<?php
$ahora = time();
print ($ahora);
?>
<br />
<?php
$ahora = time();
$dosHorasMas = $ahora + 7200;
/* 60 segundos cada minuto, por 120 minutos que tienen las
dos horas, da 7200 segundos */
print ("El plazo vence en: ".$dosHorasMas." segundos");
?>