<?php
$cadena = "América Latina unida";
$texto_buscado = "A";

$posicion = strpos($cadena,$texto_buscado);

if( $posicion===false ){

	echo "No se encontró";

} else {

	echo "Sí se encontró, en la posición: $posicion";

}
?>