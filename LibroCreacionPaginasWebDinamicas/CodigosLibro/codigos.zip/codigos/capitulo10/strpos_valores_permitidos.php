<?php
function permitirLetras($cadena){
	$letras =
	"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	$longitud = strlen($cadena);

	for( $i=0; $i<$longitud; $i++){

		if(strpos($letras,substr($cadena,$i,1))===false ){
			// $cadena no es válido
			return false;
		}
	}
	// $cadena es válido
	return true;

}

// ejecutamos la función con un caracter no permitido:
if( permitirLetras("Pepé") ) {

	echo "Correcto";

} else {

	echo "Utiliza caracteres prohibidos";

}
?>