<?php
$claves = file("claves.txt");
$cuantos = count($claves);
$encontrado = "no";

for ($i=0; $i<$cuantos; $i++){

// Desde ya que damos por supuesto que llegó "password" mediante el método "post", si no, no funcionará:
	if ( strtolower(trim($claves[$i])) == strtolower($_POST["password"]) ){
		$encontrado = "sí";
	}

}

if ($encontrado == "no"){

	include ("error.php"); // Recordemos crear este archivo

} else {

	include ("secreto.php"); // Recordemos crear este archivo

}
?>