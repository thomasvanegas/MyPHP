<?php
// Supongamos que tenemos almacenados en variables un día, mes y año.
$dia = 15;
$mes = 11;
$anio = 2020;
$fecha = sprintf("%02d-%02d-%04d", $dia, $mes, $anio);
echo $fecha;
?>

<?php
$importe1 = 25.55;
$importe2 = 15.15;
$total = $importe1 + $importe2;
// Si imprimimos $total mostrará "40.7"

$dosDecimales = sprintf("%01.2f", $total);
echo $dosDecimales; // Ahora mostrará "40.70", con dos decimales
?>