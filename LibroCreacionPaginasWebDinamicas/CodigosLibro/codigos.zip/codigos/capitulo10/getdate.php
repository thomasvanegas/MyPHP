<?php
$ahora = time();
$detalle = getdate($ahora);// Convirtió a $detalle en una matriz con las diez celdas que acabamos de mencionar

print("<p>Hora: ".$detalle["hours"]."<br>");
print("Minutos: ".$detalle["minutes"]."<br>");
print("Segundos: ".$detalle["seconds"]."</p>");
print("<p>Día: ".$detalle["mday"]."<br>");
print("Mes: ".$detalle["mon"]."<br>");
print("Año: ".$detalle["year"]."</p>");
print("<p>Día de la semana: ".$detalle["wday"]."</p>");
print("<p>Días desde el principio del año: ".$detalle["yday"]."</p>");
print("<p>Nombre en inglés del día de la semana: ".$detalle["weekday"]."</p>");
print("<p>Nombre en inglés del mes: ".$detalle["month"]."</p>");
?>