<?php
$filas = file("usuarios.txt");
$cuantos = count($filas);

for ($i=0; $i<$cuantos; $i++){

	$partes = explode(":", $filas[$i]);
	print ("<p>Usuario: ".$partes[0]." - Clave: ".$partes[1]."</p>");

}
?>