<?php
$cadena = "América Latina unida";
$abuscar = "unida";
$posicion = strpos($cadena,$abuscar);
print($posicion);
// Imprimirá 15 -comienza desde cero-.
?>