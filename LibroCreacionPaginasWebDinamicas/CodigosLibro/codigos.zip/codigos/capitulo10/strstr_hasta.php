<?php
$email = "casilla@dominio.com.ar";
$caracter = "@";

$dominio = strstr($email,$caracter,true);

print($dominio);
// Imprimirá "casilla"
?>