<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Validar</title>
</head>
<body>
<?php
function validarDatos($campo){

	// Matriz con las posibles cabeceras a utilizar por un spammer
	$cabeceras = array("Content-Type:", "MIME-Version:", "Content-Transfer-Encoding:", "Return-path:", "Subject:", "From:", "Envelope-to:", "To:", "bcc:", "cc:");

	/* Ahora comprobamos que entre los datos no se encuentre alguna de las cadenas de la matriz. Si se encuentra alguna de esas cadenas, se muestra un mensaje */
	$bandera = "si";// Usamos un flag o señal

	foreach ($cabeceras as $valor){
		
		if( strpos( strtolower($campo),strtolower($valor))!==false ) {
		
			$bandera = "no"; // Cambiamos la señal
		
		} // Cierra if
	} // Cierra bucle

	if ($bandera == "no"){
	
		return false;
	
	} else {
	
		return true;
	
	}
} // Cierra función
?>

<?php
// Vamos a validar un campo de formulario:
if ( isset($_POST["nombre"]) ){ // Recordemos enviar este dato hacia esta página

	if (!validarDatos($_POST["nombre"]) ){
	
		echo "<p>ATENCION: Detectamos que se está intentando enviar caracteres no permitidos dentro del Nombre.</p>";
	
	} 
}
?>
</body>
</html>