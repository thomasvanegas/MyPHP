<?php
/* Suponemos que venimos de un formulario donde el usuario
ya completó su dirección en la variable $email
*/

if ( preg_match("/@/", $email) ){

	print ("<p>Casilla correcta</p>");

} else {

	print ("<p>A su casilla le falta la arroba</p>");

}
?>