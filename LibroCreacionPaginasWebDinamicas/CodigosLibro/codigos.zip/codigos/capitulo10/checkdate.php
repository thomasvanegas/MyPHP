<?php
$primera = checkdate(12,32,2020);

if ($primera){ // preguntamos tácitamente si la función devolvió “true”, verdadero

	print("Fecha correcta");
	
} else {

	print("Fecha equivocada");

}
?>