<?php
date_default_timezone_set('America/Argentina/Buenos_Aires');
?>

<?php
print (date("d-m-Y")); // Observar el separador "-"
?>

<br>

<?php
print ("Hoy es ".date("d de m del Y"));
?>

<br>

<?php
print ("Hoy es ".date("d")." de ".date("m")." del ".date("Y"));
?>

<br>

<?php
$hora = date("H:i:s",1451606399);
echo $hora;
?>