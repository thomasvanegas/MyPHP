<?php
$email = "casilla@dominio.com.ar";
$caracter = "@";

$dominio = strstr($email,$caracter);

print($dominio);
// Imprimirá "@dominio.com.ar"
?>