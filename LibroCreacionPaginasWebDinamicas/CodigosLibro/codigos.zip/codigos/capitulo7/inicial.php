<?php
setcookie("mivariable", "datos, datos y mas datos", time()+60);
// Recordemos que esto es imprescindible que esté al inicio del archivo
?>
<!DOCTYPE html>
<html lang="es">
<head>
...
</head>
<body>
<h1>¡Ya se creó la cookie!</h1>
</body>
</html>