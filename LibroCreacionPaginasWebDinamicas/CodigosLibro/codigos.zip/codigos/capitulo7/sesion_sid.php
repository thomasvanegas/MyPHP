<?php
session_start();
echo "Su nombre es: ".$_SESSION["nombre"];
?>
<html>
<!-- etc -->
<p><a href="pagina1.php?<?php echo SID;?>">Volver</a></p>

<!-- etc -->

<p><a href="pagina1.php?<?php echo session_name();?>=<?php
echo session_id();?>">Volver</a></p>

</html>