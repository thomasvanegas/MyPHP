<?php
setcookie("prueba",$valor,time()+3600,"/foro/","",1);
?>

<?php
setcookie("ingreso",$datos,time()+(60 * 60 * 24),"","ar.undominio.com",0);
?>

<?php
setcookie("nombre",$datos,0);
?>