<?php
setcookie("nombre");
?>
<?php
unset($_COOKIE["nombre"]);
?>