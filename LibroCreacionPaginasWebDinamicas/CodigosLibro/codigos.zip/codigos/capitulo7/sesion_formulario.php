<?php
session_start();
$_SESSION["dato"] = "clientenuevo";
?>
<form action="pagina2.php?<?php echo SID; ?>">
<input...etc...>
</form>

<!-- o por el otro método: -->

<form action="pagina2.php?<?php echo session_name();?>=<?php
echo session_id();?>">
<input...etc...>
</form>