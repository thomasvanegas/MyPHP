<?php
setcookie("nombre","Juancito");
?>
<!DOCTYPE html>
<html ...etc...
</html>