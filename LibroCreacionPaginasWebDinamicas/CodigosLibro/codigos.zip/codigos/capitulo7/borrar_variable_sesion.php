<?php
session_start();
unset($_SESSION["dato"]);
// si a continuación queremos usar esa variable, no estará más disponible:
echo $_SESSION["dato"]; // producirá un error
?>