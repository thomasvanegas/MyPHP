<?php
define("TITULO", "Bienvenidos a mi sitio en castellano");
define("SUBTITULO", "Este es un subtítulo en castellano...");
define("AVANCE", "Este es un texto complementario...");
define("NOTICIA", "Este es el texto largo en castellano...");
?>