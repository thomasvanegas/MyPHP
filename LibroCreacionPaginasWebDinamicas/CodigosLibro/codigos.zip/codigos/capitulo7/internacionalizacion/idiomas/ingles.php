<?php
define("TITULO", "Welcome to my website");
define("SUBTITULO", "This is a subtitle...");
define("AVANCE", "This is a complementary text...");
define("NOTICIA", "The large text in english...");
?>