<?php
session_start();
if ( isset($_POST["idioma"]) ) {

	$_SESSION["idioma"] = $_POST["idioma"];
	$idioma = $_SESSION["idioma"];
	include("idiomas/$idioma.php");
	
} elseif ( isset($_SESSION["idioma"]) ) {
	
	$idioma = $_SESSION["idioma"];
	include("idiomas/$idioma.php");

} else {

	include("idiomas/espanol.php"); // Un idioma por defecto.
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<!-- etc. -->
</head>
<body>
<div id="titulo"><?php echo TITULO; ?></div>
<div id="subtitulo"><?php echo SUBTITULO; ?></div>
<div id="avance"><?php echo AVANCE; ?></div>
<div id="noticia"><?php echo NOTICIA; ?></div>
etc...
<div id="menu">
  <form name="formu1" method="post" action="index.php">
    <fieldset>
    <legend>Elija su idioma</legend>
    <select name="idioma">
      <option value="espanol">Castellano</option>
      <option value="ingles">English</option>
    </select>
    <input type="submit" value="Elegir">
    </fieldset>
  </form>
</div>
</body>
</html>