<?php
echo "Hola Mundo entre comillas dobles!";
echo '<html>
<head>
<title>Envuelvo entre comillas simples</title>
</head>
<body>"Esto tiene comillas dobles, "muchas comillas", y no
importa"
</body>
</html>';
?>