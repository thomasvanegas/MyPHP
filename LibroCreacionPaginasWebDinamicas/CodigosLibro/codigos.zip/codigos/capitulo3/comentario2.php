<?php
$clave = "xyz345"; // recordar avisar al Gerente si la cambiamos
$tolerancia = 3; # es la cantidad de reintentos de ingreso tolerados con una contraseña equivocada
echo $clave; /* recordar que si mostramos esto, previamente deberíamos informar al usuario, para que no lo exponga a la vista de otros.
*/
?>