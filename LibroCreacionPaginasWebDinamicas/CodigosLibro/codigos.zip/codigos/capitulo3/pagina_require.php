<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Página que incluye otros archivos</title>
</head>
<body>
<div id="contenedor">
  <?php require("encabezado.php"); ?>
  <div id="contenidoPrincipal"> 
  Contenido principal 
  </div>
  <?php include_once("botonera.php"); ?>
  <?php require_once("pie.php"); ?>
</div><!-- cierre del contenedor -->
</body>
</html>