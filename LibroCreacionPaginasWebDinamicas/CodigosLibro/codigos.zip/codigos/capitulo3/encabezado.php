<div id="encabezado">
Encabezado
</div>