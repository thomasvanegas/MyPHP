<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Hola</title>
</head>
<body>
<p>Esto estaba escrito en HTML.</p>
<?php
print("<p>Hola mundo! Esto lo escribió el intérprete de PHP</p>");
?>
</body>
</html>