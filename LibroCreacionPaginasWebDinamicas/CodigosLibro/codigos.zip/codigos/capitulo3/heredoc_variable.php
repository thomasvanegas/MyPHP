<?php
$codigo = <<<EOT
<p>Este texto puede tener dentro "comillas" sin necesidad de
escaparlas.</p>
<p>También procesa (reemplaza por su valor) las $variables que hubiera dentro del código, tema que veremos próximamente.</p>
EOT;
echo $codigo;
?>