<?php
$variable = "valor"; //comentario de una línea
$cifra = 123; #otro comentario de una línea
echo $variable; /* comentario
multi
línea
*/
?>