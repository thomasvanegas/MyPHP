<?php
echo <<<EOT
<p>Este texto puede tener dentro "comillas" sin necesidad de
escaparlas.</p>
<p>También procesa (reemplaza por su valor) las $variables que hubiera dentro del código, tema que veremos próximamente.</p>
<p>Esta construcción del lenguaje llamada heredoc es ideal para incluir largos bloques de código HTML.</p>
EOT;
?>