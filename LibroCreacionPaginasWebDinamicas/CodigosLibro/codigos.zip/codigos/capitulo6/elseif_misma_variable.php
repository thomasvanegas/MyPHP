<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Elseifs que evalúan una misma variable</title>
</head>
<body>
<p>
  <?php
if ($dia == "lunes"){

	print ("¡Feliz día de la Luna!");
	
} elseif ($dia == "martes"){

	print ("¡Feliz día de Marte!");
	
} elseif ($dia == "miércoles"){

	print ("¡Feliz día de Mercurio!");
	
} elseif ($dia == "jueves"){

	print ("¡Feliz día de Júpiter!"
	
} elseif ($dia == "viernes"){

	print ("¡Feliz día de Venus!");
	
} elseif ($dia == "sábado"){

	print ("¡Feliz día de Saturno!"
	
} elseif ($dia == "domingo"){
	
	print ("¡Feliz día del Sol!");
	
}
?>
</p>
</body>
</html>