<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Rango</title>
</head>
<body>
<?php
$mes = 10; // supongamos que esto llegaría desde un formulario

if ($mes > 0 and $mes <= 12){

	print ("<p>Usted eligió el mes: $mes");

} else {

	print ("<p>Ha elegido un mes inexistente</p>");

}
?>
</body>
</html>