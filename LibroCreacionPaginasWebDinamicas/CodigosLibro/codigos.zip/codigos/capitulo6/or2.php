<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Operador lógico "or"</title>
</head>
<body>
<p>
<?php
$tarjeta = "VISA";
$cupon = 19876;

if ($tarjeta == "VISA" or $cupon <> ""){

	print ("Podemos tomar su pedido");
	
} else {

	print ("No puede elegir VISA y a la vez colocar un código de cupón de descuento, y tampoco puede elegir otro medio de pago sin ingresar un código de cupón.");
}
?>
</p>
</body>
</html>