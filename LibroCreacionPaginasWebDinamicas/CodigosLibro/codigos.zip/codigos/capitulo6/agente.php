<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Condicional</title>
</head>
<body>
<p>
  <?php
if ($_POST["password"]== "superagente86") {

	echo "<h1>Maxwell, atienda el zapatófono que lo estamos llamando de Control</h1>";

}
?>
</p>
</body>
</html>
