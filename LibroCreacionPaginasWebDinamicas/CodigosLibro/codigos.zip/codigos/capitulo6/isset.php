<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Isset</title>
</head>
<body>
<?php
if ( isset($_POST["nombre"],$_POST["apellido"],$_POST["edad"])
){

	// Sólo si todos esos datos están presentes, devuelve verdadero y se ejecuta lo que esté entre las llaves del if
}
?>
</body>
</html>