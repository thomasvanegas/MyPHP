<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Operador lógico "or"</title>
</head>
<body>
<p>
<?php
if ($_POST["ciudad"] == "Ciudad 1" or $_POST["ciudad"] ==
"Ciudad 2" or $_POST["ciudad"] == "Ciudad 3"){

	print ("¡Zona correcta! Recibirá su pedido.");

} else {

	print ("Está fuera del área de cobertura.");

}
?>
</p>
</body>
</html>