<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Condicional con elseif</title>
</head>
<body>
<p>
  <?php
if ($_POST["edad"] < 18){

	print ("¡Hola niño!");

} elseif ($_POST["edad"] < 30){

	print ("¡Hola joven!");

} elseif ($_POST["edad"] > 29){

	print ("¡Hola adulto!");

}
?>
</p>
</body>
</html>