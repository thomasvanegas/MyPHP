<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Operadores de comparación</title>
</head>
<body>
<p>
<?php
if ($_POST["edad"] <= 17) {

	print ("Es menor a 18 años");

}
?>

<?php
if ($_POST["nombre"] <> "Pepe") {

	print ("No sos Pepe");

}

if ($_POST["nombre"] != "Pepe") {

	print ("No sos Pepe");
	
}
?>
</p>
</body>
</html>