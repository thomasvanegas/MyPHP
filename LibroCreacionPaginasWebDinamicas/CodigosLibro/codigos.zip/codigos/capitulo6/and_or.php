<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Operadores lógicos "and" y "or"</title>
</head>
<body>
<p>
<?php
if ($_POST["edad"] >= 18 and $_POST["edad"] <= 65 or $_POST["estado"] == "viudo"){

	print ("Está en el rango solicitado");
	
}
?>
</p>
</body>
</html>