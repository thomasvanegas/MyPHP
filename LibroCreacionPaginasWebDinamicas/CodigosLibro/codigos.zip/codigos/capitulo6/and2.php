<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Operador lógico "and"</title>
</head>
<body>
<p>
<?php
$usuario = "pepe";
$clave = 99999;

if ($nombre = "pepe" and $clave = "123456"){

	print ("¡Bienvenido Pepe!");
	
} else {

	print ("No lo conocemos, disculpe pero queda fuera");

}
?>
</p>
</body>
</html>