<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Operador lógico "and"</title>
</head>
<body>
<p>
<?php
if ($_POST["edad"] >= 18 and $_POST["edad"] <= 65) {

	print ("Está en el rango solicitado");

} else {

	print ("Fuera del rango");

}
?>
</p>
</body>
</html>