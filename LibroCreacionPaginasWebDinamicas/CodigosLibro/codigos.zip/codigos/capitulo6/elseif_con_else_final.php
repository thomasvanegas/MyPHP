<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Condicional con elseif</title>
</head>
<body>
<p>
<?php
if ($_POST["sexo"] == "masculino"){

	print ("¡Hola Hombre!");
	
} elseif ($_POST["sexo"] == "femenino"){

	print ("¡Hola Mujer!");
	
} else {

	print ("Hola...");

}
?>
</p>
</body>
</html>