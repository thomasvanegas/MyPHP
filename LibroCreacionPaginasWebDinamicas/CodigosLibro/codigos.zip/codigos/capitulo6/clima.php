<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Condicional con else</title>
</head>
<body>
<p>
  <?php
 // Definimos esto aquí, pero podría venir de un enlace o formulario:
$clima = "lluvia"; 
// probar a cambiarlo por otra cosa y ver cómo ejecuta otro bloque.

if ($clima == "lluvia") {

	echo "Llevar paraguas";

} else {

	echo "No llevar paraguas";

}
?>
</p>
</body>
</html>