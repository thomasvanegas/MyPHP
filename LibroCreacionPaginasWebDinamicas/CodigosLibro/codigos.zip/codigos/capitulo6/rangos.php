<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Rangos</title>
</head>
<body>
<?php
$total = 145; // supongamos que esto llegaría desde un formulario

if ($total > 0 and $total <= 500){

	if ($total <= 100){

		print ("¡Muy barato! Menos de 100 pesos...");

	} elseif ($total <= 200){

		print ("Buen precio, entre 101 y 200 pesos.");

	} elseif ($total <= 500){

		print ("Algo caro, entre 201 y 500 pesos.");
	
	}

} else {

	print ("El valor está fuera del rango permitido de 1 a
500");

}
?>
</body>
</html>