<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Vacíos</title>
</head>
<body>
<?php
if ($_POST["domicilio"] == ""){

	// si es cierto, es que está vacío

}
?>

<?php
if ($_POST["domicilio"] <> ""){

	// si es cierto, es que NO está vacío

}
?>

<?php
if ($_POST["domicilio"] != ""){

	// si es cierto, es que NO está vacío

}
?>
</body>
</html>