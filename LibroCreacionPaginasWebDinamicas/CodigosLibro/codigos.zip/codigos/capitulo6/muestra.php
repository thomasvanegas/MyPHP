<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Dirección</title>
</head>
<body>
<p>
<?php
print ("Su direccion es: ");
print ($_POST["domicilio"]);
?>
</p>
</body>
</html>