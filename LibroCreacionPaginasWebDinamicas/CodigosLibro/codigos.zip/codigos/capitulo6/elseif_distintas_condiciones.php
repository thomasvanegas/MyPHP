<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Condicional con elseif, distintas condiciones</title>
</head>
<body>
<p>
  <?php
if ($_POST["sexo"] == "masculino"){

	print ("¡Hola Hombre!");
	
} elseif ($_POST["estado"] == "soltera"){

	print ("¡Hola Mujer soltera!");

} elseif ($_POST["edad"] > 70){

	print ("¡Hola abuela!");
	
}
?>
</p>
</body>
</html>