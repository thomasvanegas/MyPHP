<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Operadores de comparación: menor, menor o igual</title>
</head>
<body>
<p>
<?php
if ($_POST["edad"] < 18{

	print ("Es menor a 18 años");

}

if ($_POST["edad"] <= 17{

	print ("Es menor a 18 años");

}
?>
</p>
</body>
</html>