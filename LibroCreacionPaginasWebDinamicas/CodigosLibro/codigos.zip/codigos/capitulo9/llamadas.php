<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Ejecutar funciones ya declaradas</title>
</head>
<body>
<?php
include("funciones.php");

// Primero cargamos con datos un par de matrices:
$propiedades = array("casas", "departamentos", "campos",
"terrenos", "quintas");

$vehiculos = array("autos", "motos", "camiones",
"cuatriciclos", "bicicletas");

print("<h2>Lista de Propiedades:</h2>");

// Ahora llamamos a la función para que las muestre:
echo listarMatriz($propiedades);// Esto llama a la función y el echo escribe lo que ésta devolvió

print("<h2>Lista de Vehículos:</h2>");

$resultado = listarMatriz($vehiculos); // Esto llama a la función otra vez, pero ahora almacenamos en una variable intermedia lo que devolvió, y luego la mostramos con echo
echo $resultado;
?>
</body>
</html>