<?php
function inflacion($precio,$suba){

	$precio = $precio * $suba;
    
	global $aumento; // Estamos anunciando que nos referiremos a una variable externa a la función
	
    $aumento = 1.50; // Esta línea modifica la variable externa, cada vez que sea llamada esta función
	
    return $precio;
}

$producto1 = 100;

$aumento = 1.10; // Ésta es la variable externa, hasta aquí vale 1.10 ya que aún no llamamos a la función

print("<p>El producto 1 vale: ".$producto1." antes del aumento, y la variable \$aumento todavía vale: ".$aumento."</p>");

$resultado = inflacion($producto1,$aumento);

print("<p>Ahora el producto 1 vale: ".$resultado."</p>");
print("<p>La variable \$aumento después de llamar a la función vale: ");
print($aumento."</p>");
?>