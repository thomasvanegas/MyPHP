<?php
function multiplicar($numero,$otro){

	$numero = $numero * $otro;
    
	$GLOBALS ["cifraB"] = 9; // Estamos cambiando una variable de fuera de la función
	
    return $numero;
}

$cifraA = 100;
$cifraB = 5;

print("<p>El primer número vale: ".$cifraA."</p>"); // vale 100
print("<p>El segundo número (o sea, \$cifraB) vale: ".$cifraB."</p>");// vale 5

print("<p>La multiplicación da como resultado: ");
$resultado = multiplicar($cifraA,$cifraB);
print($resultado."</p>"); // muestra 500

print("<p>Y ahora, \$cifraB luego de ejecutar la función vale: ".$cifraB."</p>");// ahora vale 9
?>