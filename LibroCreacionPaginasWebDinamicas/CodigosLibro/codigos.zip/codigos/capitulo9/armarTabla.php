<?php

function armarTabla($filas){
	$codigo = '<table>';

	for ( $i=1; $i<=$filas; $i=$i+1){
		// Llamamos a una función que se especialice en calcular el módulo y devuelva true o false
		if ( modulo($i,2)==false ){
		
			$codigo = $codigo.'<tr><td class=”par”>Esta es la fila número'.$i.'</td></tr>';
			
		} else {
		
			$codigo = $codigo.'<tr><td class=”impar”>Esta es la fila número'.$i.'</td></tr>';
			
		}
	
	}

	$codigo = $codigo.'</table>';
	return $codigo; // Le decimos qué datos devolverá al lugar 	donde fue llamada, o sea la variable $codigo
}

// Llamamos a la función:
$tabla = armarTabla($_POST["numero"]); 
// Por supuesto, debemos hacerle llegar "numero" desde un formulario, mediante el método "post".
// Y luego podemos hacer un echo de $tabla si es conveniente.