<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Validar correo con funciones</title>
</head>
<body>
<?php
// Primer paso: verificamos que el dato de entrada esté presente, no esté vacío, y lo traspasamos a una variable local llamada $correo:
if( isset($_POST["correo"]) and $_POST["correo"]<>"" ){

	$correo = $_POST["correo"];
	
	// Segundo paso: validar la casilla
	if( comprobarCasilla($correo)==true ){
	
		// Tercer paso: si era correcta, guardarla en un archivo
		if( escribirArchivo($correo)==true ){
		
			// Cuarto paso: si pudo almacenarse, mostrar un mensaje
			echo "<p>¡Gracias por suscribirse!</p>";

		} else { // Quinto paso: si no pudo almacenarse, mostrar un mensaje
	
			echo "<p>Error al guardar los datos, intente nuevamente</p>";
		
		} // fin pasos 3, 4 y 5

	} else { // Sexto paso: si la casilla no era válida, mostrar un mensaje 
	
		echo "<p>La casilla no es válida, vuelva al formulario</p>";

	} // fin paso 2
	
} else { // Séptimo paso: si no estaba presente o estaba vacía la casilla, mostrar un mensaje
	
	echo "<p>No proporcionó ninguna casilla de correo, vuelva al formulario</p>";

} // fin paso 1
?>
</body>
</html>