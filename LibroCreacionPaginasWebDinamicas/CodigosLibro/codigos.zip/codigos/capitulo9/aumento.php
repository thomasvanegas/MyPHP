<?php
function aumento($precio, $porcentaje){

	$total = $precio + ($precio * $porcentaje / 100);
	
    return $total;
}

$resultado = aumento(12.99, 5);
// Proporcionamos la misma cantidad de datos que de parámetros tenga la función, en este caso, dos, separados por comas

print("<p>Nuevo precio: ".$resultado."</p>");
?>