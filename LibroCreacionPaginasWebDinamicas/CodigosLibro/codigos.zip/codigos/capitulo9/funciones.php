<?php
function listarMatriz($matriz){

	$codigo = "<ul>";
	
	foreach ($matriz as $valor){
	
		$codigo = $codigo."<li>".$valor."</li>";
	
	}
	
	$codigo = $codigo."</ul>";
	
    return $codigo;
}
?>