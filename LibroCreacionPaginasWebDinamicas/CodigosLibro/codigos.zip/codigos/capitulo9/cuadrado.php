<?php
function cuadrado($numero){
	
	$total = $numero * $numero;
	
    return $total;
}

$cantidad = 6;
$resultado = cuadrado($cantidad);
// Ya ejecutamos la función, $resultado almacena un 36

print("<p>".$cantidad." al cuadrado da: ".$resultado."</p>");
// Mostramos el resultado
?>