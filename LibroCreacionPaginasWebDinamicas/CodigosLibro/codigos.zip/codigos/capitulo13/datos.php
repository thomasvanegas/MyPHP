<?php
$host = "localhost";
$usuario = "root";
$clave = "clave";
$base = "cursos";
?>