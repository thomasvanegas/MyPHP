<?php
// Incluimos los datos de conexión y las funciones:
include("datos.php");
include("funciones.php");

// Usamos esas variables:
if ( conectarBase($host,$usuario,$clave,$base) ){

	// Validamos que hayan llegado estas variables, y que no estén vacías:
	if ( isset($_POST["nombre"],$_POST["email"],$_POST["mensaje"]) and $_POST["nombre"]!="" and $_POST["email"]!="" and $_POST["mensaje"]!="" ){
	
		// Traspasamos a variables locales, para evitar complicaciones con las comillas:
		$nombre = $_POST["nombre"];
		$email = $_POST["email"];
		$mensaje = $_POST["mensaje"];
		
		// Preparamos la oden SQL:
		$consulta = "INSERT INTO mensajes(id,nombre,email,mensaje) VALUES('0','$nombre','$email','$mensaje')";

		// Aquí ejecutaremos esa orden

	} else {
		
		echo '<p>Por favor, complete el <a href="formulario.html">formulario</a></p>';

	}

} else {

	echo "<p>Servicio interrumpido</p>";

}
?>