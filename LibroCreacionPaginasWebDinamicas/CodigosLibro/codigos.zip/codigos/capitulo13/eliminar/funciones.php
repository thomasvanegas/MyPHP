<?php
function conectarBase($host,$usuario,$clave,$base){

	if (!$enlace = @mysql_connect($host,$usuario,$clave)){

		return false;
	
	} else {
	
		return $enlace;
	
	}

}

function consultar($conexion, $consulta){

	if (!$datos = mysqli_query($conexion,$consulta) or mysqli_num_rows($datos)<1){

		return false; // si fue rechazada la consulta por errores de sintaxis, o ningún registro coincide con lo buscado, devolvemos false

	} else {

		return $datos; // si se obtuvieron datos, los devolvemos al punto en que fue llamada la función
		
	}
}


function tabular($datos){

	// Abrimos la etiqueta table una sola vez:
	$codigo = '<table border="1" cellpadding="3">';

	// Vamos acumulando de a una fila "tr" por vuelta:
	while ( $fila = @mysqli_fetch_array($datos) ){
		
		$codigo .= '<tr>';
		
		// Vamos acumulando tantos "td" como sea necesario:
		$codigo .= '<td>'.utf8_encode($fila["id"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["nombre"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["apellido"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["edad"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["pais"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["especialidad"]).'</td>';
		
		// Agregamos dos "td" más:
		$codigo .= '<td><a href="borrar.php?codigo='.$fila["id"].'">BORRAR</a></td>';
		$codigo .= '<td>MODIFICAR</td>';
	
		// Cerramos un "tr":
		$codigo .= '</tr>';

	}

	// Finalizado el bucle, cerramos por única vez la tabla:
	$codigo .= '</table>';
	
	return $codigo;
	
}
?>