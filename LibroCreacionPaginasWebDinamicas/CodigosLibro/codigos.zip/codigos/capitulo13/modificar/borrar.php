<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Borrar</title>
</head>

<body>
<?php
// Incluimos los datos de conexión y las funciones:
include("conexion.php");
include("funciones.php");

// Verificamos la presencia del código esperado:
if ( isset($_GET["codigo"]) and $_GET["codigo"]<>"" ){

	// Nos conectamos:
	if ( $con = conectarBase($host,$usuario,$clave,$base) ){

		// Traspasamos a una variable local para evitar problemas con las comillas:
		$codigo = $_GET["codigo"];
		$consulta = "DELETE FROM empleados WHERE id='$codigo'";

		if ( mysqli_query($con, $consulta) ){

			echo "<p>Registro eliminado.</p>";

		} else {
		
			echo "<p>No se pudo eliminar</p>";

		}

	} else {
		
		echo "<p>Servicio interrumpido</p>";
	
	}

} else {

	echo '<p>No se ha indicado cuál registro eliminar.</p>';

}

echo '<p>Regresar al <a href="listado.php">listado</a></p>';
?>
</body>
</html>