<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Listado</title>
</head>

<body>
<?php
// Incluimos los datos de conexión y las funciones:
include("conexion.php");
include("funciones.php");

// Usamos esas variables:
if ( $con = conectarBase($host,$usuario,$clave,$base) ){

	$consulta = "SELECT * FROM empleados";
	
	if ( $paquete = consultar($con, $consulta) ){

		// Llamamos a una función que muestre esos datos
		$codigoTabla = tabular($paquete);
		echo $codigoTabla;

	} else {
		
		echo "<p>No se encontraron datos</p>";
	}
	
} else {

	echo "<p>Servicio interrumpido</p>";

}
?>
</body>
</html>