<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Modificar</title>
</head>

<body>
<?php
// Incluimos los datos de conexión y las funciones:
include("conexion.php");
include("funciones.php");

// Verificamos la presencia de los datos esperados (deberíamos validar sus valores, aunque aquí no lo hagamos para abreviar):
if ( isset($_POST["nombre"],$_POST["apellido"],$_POST["edad"],$_POST["especialidad"],$_POST["codigo"]) ){

	// Nos conectamos:
	if ( $con = conectarBase($host,$usuario,$clave,$base) ){

		// Evitamos problemas con codificaciones:
		@mysqli_query($con, "SET NAMES 'utf8'");
	
		// Traspasamos a variables locales para evitar problemas con comillas:
		$nombre = $_POST["nombre"];
		$apellido = $_POST["apellido"];
		$edad = $_POST["edad"];
		$pais = $_POST["pais"];
		$especialidad = $_POST["especialidad"];
		$codigo = $_POST["codigo"];

		$consulta = "UPDATE empleados SET nombre='$nombre', apellido='$apellido', edad='$edad', pais='$pais', especialidad='$especialidad' WHERE id='$codigo'";

		if ( mysqli_query($con, $consulta) ){
	
			echo "<p>Registro actualizado.</p>";

		} else {

			echo "<p>No se pudo actualizar</p>";
		}
		
	} else {
	
		echo "<p>Servicio interrumpido</p>";

	}

} else {

	echo '<p>No se ha indicado cuál registro desea modificar.</p>';
}

echo '<p>Regresar al <a href="listado.php">listado</a></p>';
?>
</body>
</html>