<?php
function conectarBase($host,$usuario,$clave,$base){

	if (!$enlace = @mysql_connect($host,$usuario,$clave)){

		return false;
	
	} else {
	
		return $enlace;
	
	}

}

function consultar($conexion, consulta){

	if (!$datos = mysqli_query($conexion, $consulta) or mysqli_num_rows($datos)<1){

		return false; // si fue rechazada la consulta por errores de sintaxis, o ningún registro coincide con lo buscado, devolvemos false

	} else {

		return $datos; // si se obtuvieron datos, los devolvemos al punto en que fue llamada la función
		
	}
}


function tabular($datos){

	// Abrimos la etiqueta table una sola vez:
	$codigo = '<table border="1" cellpadding="3">';

	// Vamos acumulando de a una fila "tr" por vuelta:
	while ( $fila = @mysqli_fetch_array($datos) ){
		
		$codigo .= '<tr>';
		
		// Vamos acumulando tantos "td" como sea necesario:
		$codigo .= '<td>'.utf8_encode($fila["id"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["nombre"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["apellido"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["edad"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["pais"]).'</td>';
		$codigo .= '<td>'.utf8_encode($fila["especialidad"]).'</td>';
		
		// Agregamos dos "td" más:
		$codigo .= '<td><a href="borrar.php?codigo='.$fila["id"].'">BORRAR</a></td>';
		$codigo .= '<td><a href="modificar.php?codigo='.$fila["id"].'">MODIFICAR</a></td>';
	
		// Cerramos un "tr":
		$codigo .= '</tr>';

	}

	// Finalizado el bucle, cerramos por única vez la tabla:
	$codigo .= '</table>';
	
	return $codigo;
	
}


function editarRegistro($datos){
	
	// Extraeremos a $fila el registro:
	if ($fila = mysqli_fetch_array($datos)){
	
		$nombreActual = utf8_encode($fila["nombre"]);
		$apellidoActual = utf8_encode($fila["apellido"]);
		$edadActual = $fila["edad"]; // La edad es un número
		$paisActual = utf8_encode($fila["pais"]);
		$especialidadActual = utf8_encode($fila["especialidad"]);
		$codigoActual = $fila["id"];

		// Aquí acumularemos en $codigo cada dato de $fila ubicado dentro de atributos value de campos
		
		$codigo = '<form action="modificado.php" method="post">
<fieldset><legend>Puede modificar los datos de este registro:</legend>
<p>
<label>Nombre:
<input name="nombre" type="text" value="'.$nombreActual.'">
</label>
</p>
<p>
<label>Apellido:
<input name="apellido" type="text" value="'.$apellidoActual.'">
</label>
</p>
<p>
<label>Edad:
<input name="edad" type="text" value="'.$edadActual.'">
</label>
</p>
<p>
<label>País:
<input name="pais" type="text" value="'.$paisActual.'">
</label>
</p>
<p>
<label>Especialidad:
<input name="especialidad" type="text" value="'.$especialidadActual.'">
</label>
</p>
<input name="codigo" type="hidden" value="'.$codigoActual.'">
<p>
<input type="submit" name="Submit" value="Guardar cambios">
</p>
</fieldset>
</form>';

	} else {

		$codigo = false;

	}

	return $codigo;

}
?>