<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Secreto</title>
</head>
<body>
<?php
// Incluimos los datos de conexión y las funciones:
include("conexion.php");
include("funciones.php");

// Validamos que hayan enviado un usuario y una clave, y que no estén vacíos:
if ( isset($_POST["usuario"],$_POST["clave"]) and $_POST["usuario"]<>"" and $_POST["clave"]<>""){

	// Traspasamos a variables locales y "limpiamos" los datos a utilizar:
	$usuario = mysql_real_escape_string($_POST["usuario"]);
	$password = mysql_real_escape_string($_POST["clave"]);
	
	// Nos conectamos:
	if ( $con = conectarBase($host,$usuario,$clave,$base) ){
	
		$consulta = "SELECT * FROM usuarios WHERE usuario='$usuario' AND clave='$password'";
	
		if ( $paquete = consultar($con, $consulta) ){
	
			echo "<p>Bienvenido al contenido secreto</p>";
	
		} else {
	
			echo "<p>No tiene derecho a acceder a nuestro contenido secreto</p>";
		}
	
	} else {
	
		echo "<p>Servicio interrumpido</p>";
	
	}

} else {

	echo '<p>No ha completado el formulario.</p>';

}

echo '<p>Regresar al <a href="formulario.html">formulario</a></p>';

?>
</body>
</html>